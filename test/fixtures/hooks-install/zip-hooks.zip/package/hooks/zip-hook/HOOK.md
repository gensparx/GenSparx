---
name: zip-hook
description: Zip hook
metadata: {"gensparx":{"events":["command:new"]}}
---

# Zip Hook

Testing hook pack install.
